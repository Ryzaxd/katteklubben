package com.example.demoIgen;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoIgenApplicationTests {

	@Test
	void contextLoads() {
	}

}
