package com.example.demoIgen;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoIgenApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoIgenApplication.class, args);
	}

}
